# Invisible Tiles & Masquerade Tile

A Pen created on CodePen.

Original URL: [https://codepen.io/austin1-proph-/pen/ByyVNjr](https://codepen.io/austin1-proph-/pen/ByyVNjr).

